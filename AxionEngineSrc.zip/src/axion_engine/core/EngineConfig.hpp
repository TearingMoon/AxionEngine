#pragma once

struct EngineConfig
{
    int updateDelay = 1;

    //TODO: Add Logger config
    //TODO: Add MessageBus config
};